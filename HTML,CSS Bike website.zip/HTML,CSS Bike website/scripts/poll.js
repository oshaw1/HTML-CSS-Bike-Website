
function getVote(int) { // applying a name to the function to be accessed from the html page
  var xmlhttp=new XMLHttpRequest();// making a request variable to get the information from the php file
  xmlhttp.onreadystatechange=function() {// this checks if the button has been clicked and runs the next if statement
    if (this.readyState==4 && this.status==200) {// this checks if the user has input a answer and moves onto the next section if they have
      document.getElementById("poll").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","poll_vote.php?vote="+int,true);//this recieves the information from the php file
  xmlhttp.send();// updating the php file with the additional results
}

// i understand this section however i couldnt get it working due to a php file not being included in the final submission
