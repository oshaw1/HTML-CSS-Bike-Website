function myFunction() {
  //this assignes a name to the funtion allowing a div to access it and run the function when a  action is complete
  document.getElementById("myDropdown").classList.toggle("show"); // this allows the content of the div to be shown on a toggle so once the user clicks it its open
}
window.onclick = function(event) {// the function is run when the window (div) is clicked
  if (!event.target.matches('.dropbtn')) {// this part checks if the part of the page clicked was the correct part to run the function using a if statement
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {// this maths section adds to see the length of a box that the function should create to house the dropdowns content
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {// this section checks if the box is open when it is clicked again if it is then the box is closed
        openDropdown.classList.remove('show');
      }
    }
  }
}
function myFunction2() {
  //this assignes a name to the funtion allowing a div to access it and run the function when a  action is complete
  document.getElementById("myDropdown2").classList.toggle("show"); // this allows the content of the div to be shown on a toggle so once the user clicks it its open
}
window.onclick = function(event) {// the function is run when the window (div) is clicked
  if (!event.target.matches('.dropbtn2')) {// this part checks if the part of the page clicked was the correct part to run the function using a if statement
    var dropdowns = document.getElementsByClassName("dropdown-content2");
    var i;
    for (i = 0; i < dropdowns.length; i++) {// this maths section adds to see the length of a box that the function should create to house the dropdowns content
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {// this section checks if the box is open when it is clicked again if it is then the box is closed
        openDropdown.classList.remove('show');
      }
    }
  }
}
